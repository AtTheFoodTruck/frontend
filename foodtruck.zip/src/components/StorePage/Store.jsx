import React from 'react';

const Store = () => {
    return (
        <div>
            Store 페이지 입니다!
        </div>
    );
};

export default Store;