import React from 'react';

const OwnerRegister = () => {
    return (
        <div>
            사장 회원가입 페이지 입니다
        </div>
    );
};

export default OwnerRegister;