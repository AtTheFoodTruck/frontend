import React from 'react';

const MemberRegister = () => {
    return (
        <div>
            개인 회원 가입 페이지
        </div>
    );
};

export default MemberRegister;