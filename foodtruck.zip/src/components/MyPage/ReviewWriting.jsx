import React from 'react';

const ReviewWriting = () => {
    return (
        <div>
            리뷰 등록 페이지 입니다.
            
        </div>
    );
};

export default ReviewWriting;