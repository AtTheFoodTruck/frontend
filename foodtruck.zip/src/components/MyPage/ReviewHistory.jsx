import React from "react";

const ReviewHistory = () => {
  return <div>리뷰 관리 페이지 입니다</div>;
};

export default ReviewHistory;
