export const DropDownMenu = [
  {
    title: "정보수정",
    path: "/userinfo-config",
    cName: "dropdown-link",
  },
  {
    title: "주문내역",
    path: "/order-list",
    cName: "dropdown-link",
  },
  {
    title: "리뷰관리",
    path: "/review-history",
    cName: "dropdown-link",
  },
];
