import React from "react";

const UserInfoConfig = () => {
  return <div>개인정보 수정 페이지 입니다.</div>;
};

export default UserInfoConfig;
