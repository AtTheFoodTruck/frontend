import React from 'react';
import styled from "styled-components";

const Box = styled.div`

`

const ProFile = () => {
    return (
        <div>
            프로필 페이지 입니다
        </div>
    );
};

export default ProFile;