import React from 'react';

const Cart = () => {
    return (
        <div>
            Cart 페이지 입니다.
        </div>
    );
};

export default Cart;